# Design System Strategy: The Kinetic Atelier

## 1. Overview & Creative North Star
**Creative North Star: "The Kinetic Atelier"**

The design system moves away from the "boxy" nature of standard SaaS platforms. Instead, it treats the Fitness Management interface as a high-end, editorial workspace. We are not just building a tracker; we are building a performance engine. 

The aesthetic is driven by **Kinetic Depth**. We achieve this by breaking the rigid grid through intentional asymmetry—think of a sidebar that feels like a solid architectural monolith (`inverse_surface`) contrasted against a main stage that feels airy, light, and fluid. We use overlapping card structures and high-contrast typography to guide the eye through complex data without the clutter of traditional lines.

---

## 2. Colors: High-Octane Contrast
The palette is designed to evoke energy (`primary`) and professional stability (`inverse_surface`).

*   **Primary Actions:** Use `primary` (#0040df) for core interactions. To add "soul," apply a subtle linear gradient from `primary` to `primary_container` (#2d5bff) at a 135-degree angle.
*   **The Sidebar Monolith:** The deep charcoal sidebar must use `inverse_surface` (#2f3133). Text on this surface must be `inverse_on_surface`.
*   **The "No-Line" Rule:** We do not use 1px solid borders to separate sections. Period. Boundaries are created through tonal shifts. For example, a workout list should sit on `surface_container_low`, while the individual workout cards sit on `surface_container_lowest`.
*   **Surface Hierarchy & Nesting:**
    *   **Base Layer:** `surface` (#f9f9fc)
    *   **Section Layer:** `surface_container` (#eeeef0)
    *   **Interactive/Elevated Layer:** `surface_container_lowest` (#ffffff)
*   **The Glass & Gradient Rule:** For floating modals or "quick-add" fitness menus, use a semi-transparent `surface` with a 20px backdrop-blur. This keeps the user connected to the dashboard context while maintaining focus.

---

## 3. Typography: The Editorial Edge
We pair **Manrope** (Display/Headlines) with **Inter** (Data/Body) to balance athletic energy with surgical precision.

*   **Manrope (The Hook):** Used for `display` and `headline` tokens. It’s wide and authoritative. Use `headline-lg` for daily performance summaries to make the user feel their progress is significant.
*   **Inter (The Engine):** Used for all `title`, `body`, and `label` tokens. Inter’s tall x-height ensures that complex heart-rate data and rep-counts remain legible even on smaller mobile screens.
*   **Hierarchical Intent:** Use `on_surface_variant` for secondary labels (e.g., "Last Workout") to create a clear visual gap between the data and the descriptor.

---

## 4. Elevation & Depth: Tonal Layering
We avoid the "pasted-on" look of heavy shadows.

*   **The Layering Principle:** Depth is achieved by stacking. A `surface_container_highest` header creates a natural "ledge" over a `surface` body. 
*   **Ambient Shadows:** For primary action buttons or active member cards, use a shadow with a 24px blur, 4% opacity, and a color derived from `on_surface`. It should feel like a soft glow of light, not a drop shadow.
*   **The "Ghost Border" Fallback:** If a border is required for high-density data tables, use `outline_variant` at **15% opacity**. It should be felt, not seen.
*   **Interactive States:** When a card is hovered, do not move it; instead, shift its background from `surface_container_lowest` to `primary_fixed_dim`.

---

## 5. Components: The Performance Kit

### Buttons
*   **Primary:** `primary` background, `on_primary` text. `md` (0.75rem) roundedness. Use a subtle inner glow (top-down) for a premium "pressed" look.
*   **Secondary:** `surface_container_high` background. No border.

### Status Indicators (Role-Based)
*   **Trainer:** `primary` (#0040df) pill with `label-sm`.
*   **Member:** `secondary` (#4959a3) pill.
*   **Alert/Issue:** `tertiary` (#993100) — use this for missed payments or failed glass goals.

### Cards & Lists
*   **The Rule:** Forbid divider lines. 
*   **Implementation:** Use 1.5rem (`xl`) vertical spacing between list items. Use a `surface_container_low` background for the container and `surface_container_lowest` for the individual items to create a "floating" effect within the section.

### Input Fields
*   **Style:** Minimalist. Background `surface_container_low`, no border. On focus, the bottom edge gains a 2px `primary` accent.

### Progress Gauges (Fitness Specific)
*   Custom circular indicators using `primary` for progress and `surface_variant` for the remaining track. Apply a 5px blur to the "active" end of the progress line to simulate movement.

---

## 6. Do’s and Don'ts

### Do:
*   **Do** use `surface_container` tiers to create hierarchy.
*   **Do** embrace white space. If a dashboard feels crowded, increase the spacing from `lg` to `xl` rather than adding a border.
*   **Do** use `manrope` for numbers. Big, bold numbers are the heartbeat of fitness tracking.

### Don't:
*   **Don't** use pure black (#000000). Use `inverse_surface` for dark backgrounds.
*   **Don't** use standard "Select" dropdowns. Use custom, wide-tappable `surface_container` list items.
*   **Don't** use high-contrast dividers. If you feel you need a line, use a 8px height `surface_container` "gap" instead.